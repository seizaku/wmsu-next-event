<?php
include 'conn.php';
// Fetch wards for dropdown
$wards_query = "SELECT id, ward_name FROM wards";
$wards_result = $conn->query($wards_query);

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $patient_id = $_POST['PatientID']; // Hidden field or passed via GET
    $name = $_POST['patient_name'];
    $gender = $_POST['gender'];
    $dob = $_POST['dob'];
    $ward_id = $_POST['ward_assigned'];

    // Update query
    $update_query = "UPDATE patients SET name = ?, gender = ?, dob = ?, ward_id = ? WHERE id = ?";
    $stmt = $conn->prepare($update_query);
    $stmt->bind_param("sssii", $name, $gender, $dob, $ward_id, $patient_id);

    if ($stmt->execute()) {
        echo "Patient updated successfully!";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
}

// Fetch patient details (optional: if editing an existing record)
$patient_id = $_GET['id'] ?? null;
$patient = null;
if ($patient_id) {
    $patient_query = "SELECT * FROM patients WHERE id = ?";
    $stmt = $conn->prepare($patient_query);
    $stmt->bind_param("i", $patient_id);
    $stmt->execute();
    $patient_result = $stmt->get_result();
    $patient = $patient_result->fetch_assoc();
    $stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Patient</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f8;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .form-container {
            background-color: white;
            padding: 20px 30px;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            width: 300px;
            text-align: center;
        }
        .form-container input,
        .form-container select,
        .form-container button {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 14px;
        }
        .form-container button {
            background-color: #6c47d9;
            color: white;
            border: none;
            cursor: pointer;
            font-size: 16px;
        }
        .form-container button:hover {
            background-color: #553bb5;
        }
        .form-container .radio-group {
            display: flex;
            justify-content: center;
            gap: 20px;
            margin: 10px 0;
        }
        .form-container .radio-group label {
            margin: 0;
        }
    </style>
</head>
<body>
    <div class="form-container">
        <form method="POST" action="">
            <input type="hidden" name="patient_id" value="<?= htmlspecialchars($patient['id'] ?? '') ?>">
            <label for="patient-name">Patient Name:</label>
            <input type="text" id="patient-name" name="patient_name" value="<?= htmlspecialchars($patient['name'] ?? '') ?>" required>
            
            <label>Gender:</label>
            <div class="radio-group">
                <label><input type="radio" name="gender" value="M" <?= (isset($patient['gender']) && $patient['gender'] == 'M') ? 'checked' : '' ?>> M</label>
                <label><input type="radio" name="gender" value="F" <?= (isset($patient['gender']) && $patient['gender'] == 'F') ? 'checked' : '' ?>> F</label>
            </div>
            
            <label for="dob">Date of Birth:</label>
            <input type="date" id="dob" name="dob" value="<?= htmlspecialchars($patient['dob'] ?? '') ?>" required>
            
            <label for="ward-assigned">Ward Assigned:</label>
            <select id="ward-assigned" name="ward_assigned" required>
                <option value="" disabled selected>Select Ward</option>
                <?php while ($ward = $wards_result->fetch_assoc()): ?>
                    <option value="<?= $ward['id'] ?>" <?= (isset($patient['ward_id']) && $patient['ward_id'] == $ward['id']) ? 'selected' : '' ?>>
                        <?= htmlspecialchars($ward['ward_name']) ?>
                    </option>
                <?php endwhile; ?>
            </select>
            
            <button type="submit">Update</button>
        </form>
    </div>
</body>
</html>
