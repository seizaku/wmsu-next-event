<?php
    include ("chuchu.php");
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="CSS/dashboardAdmin.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    
    <title>MVCH</title>
</head>

<body>
    <header>
        <h1 style="text-align: center; font-size: 30px; font-family: Arial, Helvetica, sans-serif;">MVCH</h1>
        <!-- <label for="text">Search</label> -->
        <input type="text" placeholder="Search">
        <div class="icon"><i class="fa-solid fa-id-card-clip"></i></div>
    </header>
    <div class="body">
        <nav>
            <ul>
                <a href=""><li class="reg-pat" style="background-color: #752BDF; color: white; ">Register Patient</li></a><br><br>
                <a href="patientList.php"><li>Patient List</li></a>
                <a href=""><li>Facilities</li></a>
                <a href="orderList.php"><li>Orders</li></a>
                <a href="itemList.php"><li>Inventory</li></a>
                <a href="physicianList.php"><li>Physician List</li></a>
                <a href="staffList.php"><li>Staffs</li></a>
                <a href="wardList.php"><li>Wards</li></a>
                <a href=""><li>Units</li></a>
                <a href="vendorList.php"><li>Vendors</li></a>
            </ul>
            <br>
        </nav>

        <div class="container">
            <!-- PATIENTS -->
            <div class="hehe1">
                <img src="images/inpatient.png" alt="">
                <div>
                    <b><?php echo $total_patients; ?></b>
                    <p>Total number of patients</p>
                </div>
            </div>
            
            <!-- AVAILABLE PATIENTS -->
            <div class="hehe2">
                <img src="images/staffs.png" alt="">
                <div>
                    <b><?php echo $available_staff; ?></b>
                    <p>Available Staff</p>
                </div>
            </div>
            
            <!-- INVENTORY -->
            <?php
                // DATA for pie chart
                $medical_count = isset($inventory_by_type['Medical']) ? $inventory_by_type['Medical'] : 0;
                $surgical_count = isset($inventory_by_type['Surgical']) ? $inventory_by_type['Surgical'] : 0;
            ?>

            <div class="hehe6">
                <div style="width: 50%; margin: auto;">
                    <canvas id="inventoryPieChart"></canvas>
                </div>
            </div>
            
            <!-- NUMBER OF PHYSICIANS -->
            <div class="hehe4">
                <img src="images/staffs.png" alt="">
                <div>
                    <b><?php echo $total_physicians; ?></b>
                    <p>Total Number of Physicians</p>
                </div>
            </div>
            
            <!-- PATIENTS BY GENDER -->
            <div class="hehe5">
                <?php
                //DATA for pie chart
                    $male_count = isset($patients_by_gender['M']) ? $patients_by_gender['M'] : 0;
                    $female_count = isset($patients_by_gender['F']) ? $patients_by_gender['F'] : 0;
                ?>

                <div style="width: 50%; margin: auto;">
                    <canvas id="genderPieChart"></canvas>
                </div>
            </div>

            <!-- PATIENT STATUS PIE CHART -->
            <div class="hehe7" style="box-shadow: none; background-color: #F5F6FA;">
                <button onclick="window.location.href=' '">Order</button>
                <button onclick="window.location.href=' '">Vendor</button>
            </div>

            <div class="hehe8">
                <?php
                //DATA for pie chart
                    $discharged_count = isset($patients_by_status['discharge']) ? $patients_by_status['discharge'] : 0;
                    $admitted_count = isset($patients_by_status['admitted']) ? $patients_by_status['admitted'] : 0;
                
                ?>
                <div style="width: 50%; margin: auto;">
                    <canvas id="statusPieChart"></canvas>
                </div>
            </div>
        </div>
    </div>

    
    <script>
        // INVENTORY
        const ctxInventory = document.getElementById('inventoryPieChart').getContext('2d');
        const inventoryPieChart = new Chart(ctxInventory, {
            type: 'pie',
            data: {
                labels: ['Medical', 'Surgical'],
                datasets: [{
                    label: 'Inventory Distribution',
                    data: [<?php echo $medical_count; ?>, <?php echo $surgical_count; ?>],
                    backgroundColor: [
                        '#00D89E',
                        '#752BDF'
                    ],
                    borderColor: [
                        '#00D89E',
                        '#752BDF'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'top',
                    },
                    title: {
                        display:true,
                        text:'Inventory Stocks'
                     }
                 }
             }
         });

        // GENDER
        const ctx = document.getElementById('genderPieChart').getContext('2d');
        const genderPieChart = new Chart(ctx, {
            type: 'pie',
            data: {
                labels: ['Male', 'Female'],
                datasets: [{
                    label: 'Patients by Gender',
                    data: [<?php echo $male_count; ?>, <?php echo $female_count; ?>],
                    backgroundColor: [
                        '#00D89E',
                        '#752BDF'
                    ],
                    borderColor: [
                        '#00D89E',
                        '#752BDF'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'top',
                    },
                    title: {
                        display: true,
                        text: 'Patients by Gender'
                    }
                }
            }
        });

        // PATIENT STATUS
        const ctxStatus = document.getElementById('statusPieChart').getContext('2d');
        const statusPieChart = new Chart(ctxStatus, {
            type: 'pie',
            data: {
                labels: ['Discharged', 'Admitted'],
                datasets: [{
                    label: 'Patient Status',
                    data: [<?php echo $discharged_count; ?>, <?php echo $admitted_count; ?>],
                    backgroundColor: [
                        '#00D89E',
                        '#FF8B4F'
                    ],
                    borderColor: [
                        '#00D89E',
                        '#FF8B4F'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'top',
                        labels: {
                            color: 'white'
                        }
                    },
                    title: {
                        display: true,
                        text: 'Patients by Status',
                        color: 'white'
                    }
                }
            }
        });
    </script>
    
</body>
</html>