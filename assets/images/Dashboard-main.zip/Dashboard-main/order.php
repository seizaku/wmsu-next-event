<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="CSS/order.css">

    <title>ORDER</title>
</head>
<body>
    <form action="">
        <table>
            <tr>
                <!-- ITEM -->
                <td class="big-cells" rowspan="4">
                    <div class="big-cells-div-title">Item</div>
                    <textarea name="item" class="big-cells-div-content" required></textarea>
                </td>

                <!-- STATUS -->
                <td class="small-cells">
                    <div class="small-cells-div">
                        <label for="status" class="small-cells-div-title">Status: </label>
                        <select name="status" class="small-cells-div-content">
                            <option value="Pending">Pending</option>
                            <option value="Cancelled">Cancelled</option>
                            <option value="Completed">Completed</option>
                        </select>
                    </div>
                </td>

                <!-- ORDERED BY -->
                <td class="small-cells">
                    <div class="small-cells-div">
                        <label for="ordered-by" class="small-cells-div-title">Ordered by: </label>
                        <input class="small-cells-div-content" type="text" placeholder="Patient ID" required>
                    </div>
                </td>
            </tr>
    
            <tr>
                <!-- ORDER TYPE -->
                <td class="small-cells">
                    <div class="small-cells-div">
                        <label for="order-type" class="small-cells-div-title">Order Type: </label>
                        <select name="order-type" class="small-cells-div-content">
                            <option value="Diagnostic">Diagnostic</option>
                            <option value="Drugs">Drugs</option>
                        </select>
                    </div>
                </td>

                <!-- WRITTEN BY -->
                <td class="big-cells" rowspan="3">
                    <div class="big-cells-div-title">Written by:</div>
                    <textarea name="written-by" class="big-cells-div-content"></textarea>
                </td>
            </tr>
    
            <tr>
                <!-- ORDER DATE -->
                <td class="small-cells">
                    <div class="small-cells-div">
                        <label for="order-date" class="small-cells-div-title">Order Date: </label>
                        <input class="small-cells-div-content" type="date">
                    </div>
                </td>
            </tr>
    
            <tr>
                <!-- blank, space -->
                <td id="none"></td>
            </tr>
    
            <tr>
                <!-- CONFIRM BUTTON -->
                <td colspan="3">
                    <br>
                    <button id="confirm" type="submit">Confirm</button>
                </td>
            </tr>
        </table>

    </form>
</body>
</html>