<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="CSS/medicalHistory.css">
    <title>Medical History</title>
</head>
<body>
    <br><br><br><br>
        <!-- enclosed everything in a table for easy sorting chuchu -->
        <table id="patient-medical">
            <tr>
                <td id="medical-history-title">Medical History</td>
                <td class="none" colspan="2"></td>
                
            </tr>

            <tr>
                <td colspan= "2" rowspan="4" id="med-history-details">
                    <p> <b>Allergies: </b> <!-- alergies chuchu --></p>
                    <p> <b>Medications: </b> <!-- caching caching --> </p>
                    <p> <b>Signs and symptoms:  </b> <!-- chuchus --> </p>
                    <p> <b>Past medical history: </b> <!-- chuchus --> </p>
                    <p> <b>Events leading up to the current illness or injury: </b> <!-- chuchus --> </p>

                    <br><br>
                </td>
                <td id="physician">
                    <p> <b>Physician: </b> </p>
                    <p>jhbjh <!-- Physician Name --></p>
                </td>    
            </tr>

            <tr>
                <td class="none" id="below"></td>
            </tr>
                
            <tr>
                <td id="discharge-details">
                    <p> <b>Discharge Details:</b> </p>
                    <p>jhbjh <!-- discharge details --></p>
                </td>
            </tr>

            <tr class="none">
                <td class="none" id="below"></td>
            </tr>
        </table>
</body>
</html>